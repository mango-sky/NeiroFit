# NeuroFit (MVP)

Минималистичное React-приложение AI-коуча по настроению.

## Установка

```bash
npm install
npm run dev
```
